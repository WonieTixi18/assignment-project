import 'package:flutter/material.dart';
import 'package:mobile/basic_module/photo_contant.dart';

class TiktokScreen extends StatefulWidget {
  const TiktokScreen({super.key});

  @override
  State<TiktokScreen> createState() => _TiktokScreenState();
}

class _TiktokScreenState extends State<TiktokScreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(child: _buildBody()),
      bottomNavigationBar: _buildAppbar(),
    );
  }

  Widget _buildAppbar() {
    return BottomAppBar(
      color: Colors.black,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Icon(Icons.home, color: Colors.white70),
          Icon(Icons.search, color: Colors.white70),
          Icon(Icons.bookmark, color: Colors.white70),
          Icon(Icons.more_horiz, color: Colors.white70),
        ],
      ),
    );
  }

  Widget _buildBody() {
    return Stack(
      alignment: Alignment.center,
      children: [
        _buildMainPage(),
        Positioned(top: 12, left: 0, right: 0, child: _buildTopmenu()),
      ],
    );
  }

  Widget _buildMainPage() {
    return PageView.builder(
      physics: const BouncingScrollPhysics(),
      scrollDirection: Axis.vertical,
      itemCount: imageList.length,
      itemBuilder: (context, index) {
        final item = imageList[index];
        return Stack(
          children: [
            // Background Image
            Positioned.fill(
              child: Image.network(
                item,
                fit: BoxFit.cover,
              ),
            ),
            Positioned(bottom: 100, right: 20, child: _buildRightAppbar()),
            Positioned(
              bottom: 30,
              left: 20,
              right: 100,
              child: _buildCaption(),
            ),
          ],
        );
      },
    );
  }
  Widget _buildTopmenu(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildFollowingButton(),
        _buildForyouButton()
      ],
    );
  }
  Widget _buildFollowingButton(){
    return TextButton (
      style: TextButton.styleFrom(foregroundColor: Colors.white,textStyle: TextStyle(fontSize: 18,fontWeight: FontWeight.bold)),
      onPressed: () {}, child: Text("Following"),
    );
  }
  Widget _buildForyouButton(){
    return TextButton (
      style: TextButton.styleFrom(foregroundColor: Colors.white,textStyle: TextStyle(fontSize: 18,fontWeight: FontWeight.normal)),
      onPressed: () {}, child: Text("For You"),
    );
  }
  Widget _buildRightAppbar() {
    return Column(
      children: const [
        CircleAvatar(
          radius: 25,
          backgroundImage: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRf6t96mkGf6py35-o8JCFIo4zU_Yf_loFUkw&s'),
        ),
        SizedBox(height: 16),
        Icon(Icons.favorite, color: Colors.white, size: 32),
        Text("13.2M", style: TextStyle(color: Colors.white)),
        SizedBox(height: 16),
        Icon(Icons.share, color: Colors.white, size: 32),
        Text("4.1M", style: TextStyle(color: Colors.white)),
        SizedBox(height: 16),
        Icon(Icons.comment, color: Colors.white, size: 32),
        Text("49.3K", style: TextStyle(color: Colors.white)),
      ],
    );
  }

  Widget _buildCaption() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: const [
        Text("@TIXI", style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
        Text("Hi BABE #AUB #viral #Student",
            style: TextStyle(fontSize: 18, color: Colors.white)),
      ],
    );
  }
}

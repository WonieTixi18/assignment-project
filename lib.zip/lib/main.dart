import 'package:flutter/material.dart';
import 'package:mobile/homeworktiktok/myapp.dart';
import 'basic_module/basic_app.dart';
void main() {
  runApp(Myapp());
}

